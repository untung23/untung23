﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim n, a, b, c, d, x, y, z, w As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For n = 0 To 20
            If n = 0 Then
                a = n + 2
            ElseIf n = 2 Then
                b = n + 6
            ElseIf n = 8 Then
                c = n + 6
            ElseIf n = 14 Then
                d = n + 6
            End If
        Next n

        For x = 0 To 25
            If x = 0 Then
                w = x + 4
            ElseIf x = 4 Then
                y = x + 10
            ElseIf x = 14 Then
                z = x + 10
            End If
        Next x
        TextBox1.Text = a & wrap & w & wrap & b & wrap & y & wrap & c & wrap & z & wrap & d & wrap
    End Sub

End Class
