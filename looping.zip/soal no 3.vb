﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim n, a, b, c, x, y, z, w As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For n = 0 To 243
            If n = 3 Then
                a = n + 240
            ElseIf n = 7 Then
                b = n + 20
            ElseIf n = 2 Then
                c = n + 1
            End If
        Next n

        For x = 0 To 81
            If x = 1 Then
                w = x + 80
            ElseIf x = 3 Then
                y = x + 6
            ElseIf x = 0 Then
                z = x + 1
            End If
        Next x
        TextBox1.Text = a & wrap & w & wrap & b & wrap & y & wrap & c & wrap & z & wrap
    End Sub

End Class
