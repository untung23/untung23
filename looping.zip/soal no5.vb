﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim n, a, b, c, x, y, z, w As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For n = 0 To 16
            If n = 0 Then
                a = n + 4
            ElseIf n = 4 Then
                b = n + 4
            ElseIf n = 6 Then
                c = n + 10
            End If
        Next n

        For x = 0 To 54
            If x = 0 Then
                w = x + 6
            ElseIf x = 8 Then
                y = x + 10
            ElseIf x = 10 Then
                z = x + 44
            End If
        Next x
        TextBox1.Text = a & wrap & w & wrap & b & wrap & y & wrap & c & wrap & z & wrap
    End Sub

End Class
